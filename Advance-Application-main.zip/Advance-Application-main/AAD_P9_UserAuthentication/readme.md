## practical 9

## create a flutter file >

## create a tlogin file in  then create a ty1.dart file in lib folder

## create src folder  and create widgetsthe  create framework.dart and  placeholder.dart in that

## then copy the code accordingly in file wise manner

## the chane the path of ty1.dart file path according to path loaction the run it by f5 

## then on line number 35 change tlogin() in main.dart
