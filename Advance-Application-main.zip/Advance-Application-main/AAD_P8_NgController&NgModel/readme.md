# Initialy open a new terminal
![image](https://github.com/whichcolor2101/Advance-Application/assets/154079170/e487b800-82cb-42d5-a4bc-f392e298e018)
# Type the ```ng new file_name ```  to creat a new project
![image](https://github.com/whichcolor2101/Advance-Application/assets/154079170/13d75548-8e4f-4d81-9125-2d2dcc5c0278)
# Right Click and select the 'open in interfrated terminal option'
![image](https://github.com/whichcolor2101/Advance-Application/assets/154079170/64e7d4e2-6671-4314-ab1a-a2eb474ebe0b)
# Type the command ```ng serve``` to start the project
![image](https://github.com/whichcolor2101/Advance-Application/assets/154079170/590ea3b7-863a-47e3-a7f8-6fe7e10cba12)

