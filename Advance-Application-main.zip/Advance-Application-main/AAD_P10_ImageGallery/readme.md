## practical 10

## create a flutter file >

## create  ImgDisp File in lib
## write stf then change the name of file ImgDisp And the copy the scaffold from the file and replace it at line number 13 till end 

## create assets files and put the img as per source

## the un comment line 62 and write - assets/ at line number 63 in pubspec.yaml
